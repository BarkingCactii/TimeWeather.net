<?php

define ("BODY", "products.php", true );
$thirdparty = 0;
include ('template.php')

?>