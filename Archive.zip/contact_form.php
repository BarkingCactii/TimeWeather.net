<form method=POST action="contact_webmail.php">
Subject<br>
<select size="1" name="subject">
<option selected>My Locations</option>
<option>WorldTime2003</option>
<option>WhenOnEarth</option>
<option>WorldTime2000</option>
<option>Website comment</option>
<option>Other</option>
</select><p>Email<br>
<input type=text name="email" size=45></p>
<p>Enter your comment here<br>
<textarea rows="10" name="comment" cols="37"></textarea></p>
<p>
<input type=submit value="Send Request">
</p>
</form>