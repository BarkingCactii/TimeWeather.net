    <p align="center">
    <img border="0" src="images/dolphin.gif" alt="Hello! My name is Cindy!" width="101" height="58"><p align="center">
    <u>WorldTime2003 Awards</u><p align="center">
    &nbsp;<div align="center">
              <a href="http://www.FileHeaven.com">
              <img border="0" src="images/cup_5.gif" width="91" height="50"></a></div>
            <p align="center">Awarded by
            <a href="http://www.fileheaven.com/WorldTime2003/download/8735.htm">
            FileHeaven</a> </p>
            <p align="center">
            <img title="Software - Rating : 5" src="images/downloadrate5.gif" width="63" height="13"><br>
            Awarded by
            <a href="http://www.brothersoft.com/software.asp?subcategoryid=48&softid=22437">
            BrotherSoft</a></p>
            <p align="center">
            <img src="images/5star.gif" width="100" height="62"><br>
            Awarded by <a href="http://www.filetransit.com/view.php?id=17854">
            FileTransit</a></p>
            <p align="center">
            <img src="images/shareup_logo_5.gif" width="98" height="31"><br>
            Awarded by
            <a href="http://www.shareup.com/WorldTime2003-download-9328.html">
            Shareup</a></p>
            <p align="center">
            <img src="images/5GoldDisk-Award-small.gif" border="0" width="80" height="80"><br>
            Awarded by
            <a href="http://www.worldtime2003.net-software-download.com/">
            SharewareSoft</a></p>
            <p align="center">
            <a href="http://www.topshareware.com">
            <img src="images/cup_5_2.gif" alt="5 stars rating at TopShareware.com" width="100" height="61" border="0"></a><br>
            Awarded by
            <a href="http://www.topshareware.com/WorldTime2003-download-8735.htm">
            TopShareware</a></p>
	<p align="center">
            <a href="http://www.hotfiles.com/?000ZS5">
<img hspace="0" src="http://users.tpg.com.au/adsld842/images/red81.gif" border="0" width="81" height="81"></a><br>
<font size="1">ZDNet reviews WorldTime2000 1.45 and gets the Editors Pick</font>
</p>
            <p align="center">&nbsp;</p>
