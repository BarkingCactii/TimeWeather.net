<table border="0" cellpadding="0" style="border-collapse: collapse" bordercolor="#111111" width="880" height="61">
  <tr>
    <td width="370" background="http://users.tpg.com.au/adsld842/images/logo2.gif" height="61">&nbsp;</td>
    <td height="61" valign="bottom">
    <h4 align="left"><b><i><font size="2">World Time Shareware &amp; Custom Software Development Services </font></i></b>
	</h4>
	</td>
  </tr>
</table>
<hr>
