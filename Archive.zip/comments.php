<form method=post action="process_comments.php">
Have a comment ?<br>
<input type=text name="comment" size=20><br>
&nbsp;<input type=submit value="Send Comment">
</form>
