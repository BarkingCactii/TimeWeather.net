                
<p align="center">
View different world time zones from around the world. Keep up on ever 
changing international time zones. By using WorldTime2000, you can view as many 
different time zones as your display will fit.<br>
<br>
<font size="1">Requires Windows 98/ME/NT4/2000/XP </font>
</p>
<p align="center"><a href="http://www.hotfiles.com/?000ZS5">
<img hspace="0" src="http://users.tpg.com.au/adsld842/images/red81.gif" border="0" width="81" height="81"></a><br>
<font size="1">ZDNet reviews WorldTime2000 1.45 and gets the Editors Pick</font>
</p>
<p class="small" align="center"><font size="1">Screen shots of WorldTime2000 
2.00 with different themes. Click to enlarge<a href="file:///C:/Documents%20and%20Settings/Jeff%20H/My%20Documents/My%20Webs/WebCentral/images/sample3.gif">
<br>
</a><br>
<a href="http://users.tpg.com.au/adsld842/images/sample1.gif">
<img alt="A light, cloudy theme" src="http://users.tpg.com.au/adsld842/images/sample1_small.gif" border="2" width="100" height="48"></a></font></p>
<p class="small" align="center"><font size="1">
<a href="http://users.tpg.com.au/adsld842/images/sample2.gif">
<img alt="A dark theme using a picture as the background" src="http://users.tpg.com.au/adsld842/images/sample2_small.gif" border="2" width="100" height="48"></a><a href="file:///C:/Documents%20and%20Settings/Jeff%20H/My%20Documents/My%20Webs/WebCentral/images/sample1.gif"><br>
</a><br>
<a href="http://users.tpg.com.au/adsld842/images/sample3.gif">
<img alt="Default theme" src="http://users.tpg.com.au/adsld842/images/sample3_small.gif" border="2" width="100" height="60"></a><br>
<br>
WorldTime2000 in the system tray <br>
<a href="http://users.tpg.com.au/adsld842/images/tray.gif">
<img alt="tray.gif (2458 bytes)" src="http://users.tpg.com.au/adsld842/images/tray_small.gif" border="2" width="100" height="54"></a><a href="file:///C:/Documents%20and%20Settings/Jeff%20H/My%20Documents/My%20Webs/WebCentral/images/tray.gif"><br>
<br>
</a><i>We understand that everyone has different tastes, which is why we 
consider the look and individuality of a program very important.&nbsp; We hope to 
have achieved this with WorldTime2000</i> </font></p>
<p>
&nbsp;</p>