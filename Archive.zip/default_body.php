<?php

include ('poll/poll.php' );
include ('comments.php' );
?>