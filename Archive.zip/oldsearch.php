<?php

//define ( PRODUCT, 0 );
//define ( COUNT, 10 );
define ("BODY", "process_search.php", true );
//define ("RIGHT_SIDEBAR", "default_rightside.php", true );

include ('template.php')

?>