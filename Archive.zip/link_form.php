<form method=POST action="link_submit.php">
<table border="0" width="100%" id="table1">
	<tr>
		<td width="206"><font color="#FF0000">* Your email</font></td>
		<td>
<input type=text name="email" size=45></td>
	</tr>
	<tr>
		<td width="206">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="206"><font color="#FF0000">* Title</font></td>
		<td>
<input type=text name="name" size=45></td>
	</tr>
	<tr>
		<td width="206">Brief Description</td>
		<td>
<input type=text name="briefdescription" size=45></td>
	</tr>
	<tr>
		<td width="206">Full Description</td>
		<td>
<textarea rows="3" name="description" cols="37"></textarea></td>
	</tr>
	<tr>
		<td width="206">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="206"><font color="#FF0000">* Website URL</font></td>
		<td>
<input type=text name="sitelink" size=45></td>
	</tr>
	<tr>
		<td width="206">Screenshot URL</td>
		<td>
<input type=text name="screenshotlink" size=45></td>
	</tr>
	<tr>
		<td width="206">Screenshot Thumbnail URL</td>
		<td>
<input type=text name="screenshottnlink" size=45></td>
	</tr>
	<tr>
		<td width="206">Download URL</td>
		<td>
<input type=text name="downloadlink" size=45></td>
	</tr>
	<tr>
		<td width="206">Buy URL</td>
		<td>
<input type=text name="buylink" size=45></td>
	</tr>
	<tr>
		<td width="206">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="206"><font color="#FF0000">* = Mandatory Fields</font></td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="206">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="206">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
</table>
<p>
<input type=submit value="Link to Us">
</p>
</form>