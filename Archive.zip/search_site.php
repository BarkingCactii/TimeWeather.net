<form method=post action="template.php?TB=search.php">
<p align="right">Site search 
<img border="0" src="TabView/images/search2.gif" width="16" height="16">
<input type=text name="search" size=20>
<input type=submit value="Go">
</p>
</form>


