<?php

header("Location: http://timeweather.net/template.php?TB=whenonearth_body.php");
exit();

?>