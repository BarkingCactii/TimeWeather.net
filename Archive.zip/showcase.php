		<br>	
		<p align="left"><u><b>WorldTime2000</b></u>
		<img border="0" src="http://users.tpg.com.au/adsld842/wt2kv3%20screen%201.gif" width="244" height="127" align="right"></p>
		<p align="left">&nbsp;</p>
<ul>


  <li>Track the time for an unlimited number of locations in real time</li>
	<li>Built in application skinning support - supplied with a number of skins 
	and backgrounds</li>
	<li>Skinning can be disabled for standard Windows appearance</li>
	<li>Over 1200 build in locations including Daylight savings rules</li>
	<li>Locations database can be modified to suit</li>
	<li>Global and location specific appearance customization</li>
	<li>Enhanced tool tips provides extended information</li>
	<li>Many time formatting options to choose from</li>
	<li>Includes Alarm control panel - set unlimited recurring alarms for each 
	location to play sounds, pop 
	up windows or run applications.</li>
	<li>Can be minimized to the System Tray</li>
  <li>Text automatically adjusts to the window size </li>
	<li>You get to see your name on the display when you register!</li>
</ul>
		<p align="center"><b>
		<img border="0" src="TabView/images/info.gif" width="16" height="16"> 
		<a href="template.php?TB=worldtime2000_body.php">Read more</a>&nbsp;&nbsp;
		<img border="0" src="TabView/images/buy.gif" width="15" height="15"> 
		<a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-1">Purchase</a>&nbsp;&nbsp;
		<img border="0" src="TabView/images/download.gif" width="16" height="16">
		<a href="http://users.tpg.com.au/adsld842/WorldTime2000-3.0.exe">Download</a>&nbsp; </b>
		<img border="0" src="TabView/images/search.gif" width="16" height="16">
		<b><a href="template.php?TB=worldtime2000_ss.php">Screenshots</a></b></p>
		
		
		<hr>
		<p>
			<b><u>WorldTime2003 </u></b>
			<img border="0" src="http://users.tpg.com.au/adsld842/ss1.jpg" align="right" width="225" height="126"><ul>

      <li>Free form skinned application. 
      WorldTime2003 can be very flexible variation on how the application looks, and the skin 
      dictates what details you want and don't want to see</li>
      <li>Skins can be user created, including any freeform 
      shape, colour, fonts including levels of translucency.</li>
      <li>Each skin contain the rules about what information is displayed and 
      formatted using a template. No messing around changing settings because 
      you loaded a new skin</li>
      <li>Over 1200 built-in locations including DST details, 
      latitude/longitude, dial-up area code</li>
      <li>Time is adjusted according to the Daylight Savings for that location
       </li>
      <li>Locations database can be viewed, modified and deleted. 
      Locations are backed up in case of error</li>
      <li>Unlimited number of alarms can be set for displayed locations, as well 
      as multiple alarms per location</li>
      <li>Set alarms to recur indefinitely, from daily up to monthly</li>
      <li>Snooze feature on alarms</li>
      <li>Upload the latest skins over the internet automatically</li>
      <li>Details can be added to locations being displayed such as name, email, 
      phone number</li>
      <li>Add your own locations to the database</li>
      <li>Various time formatting options</li>
      <li>Resides in the system tray</li>
      <li>Template rules in skin can be overridden</li>
      <li>Windows Install and un-install feature</li>
      <li>Low CPU usage</li>
      <li>View your local time</li>
                </ul>
                <p align="center"><b>
				<img border="0" src="TabView/images/info.gif" width="16" height="16"> 
				<a href="template.php?TB=worldtime2003_body.php">Read more</a>&nbsp;&nbsp;
				<img border="0" src="TabView/images/buy.gif" width="15" height="15"> 
				<a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-3">Purchase</a>&nbsp;&nbsp;
				<img border="0" src="TabView/images/download.gif" width="16" height="16"> 
				<a href="http://users.tpg.com.au/adsld842/WorldTime2003.exe">Download</a>&nbsp;&nbsp; </b>
				<img border="0" src="TabView/images/search.gif" width="16" height="16">
				<b><a href="template.php?TB=worldtime2003_ss.php">Screenshots</a></b></p>
                <hr><b><u>WhenOnEarth </u></b>
		<img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_ss1.gif" width="220" height="142" align="right"><ul>
  <li>Designed to be visually pleasing, easy to use and use minimal CPU 
  resources</li>
	<li>Over 1200 build in locations including Daylight savings rules</li>
  <li>See on a map where contacts are located in the world</li>
  <li>Add your own location details</li>
  <li>Display any number of locations on the map</li>
  <li>Place location times in their own small windows and minimize the main 
  display to the System tray</li>
  <li>Customize the Information displayed on the map by use of templates</li>
  <li>Map display is customizable</li>
  <li>User customizable fonts, colors and masking options</li>
  <li>Your local time information is displayed in the Status Bar</li>
  <li>Synchronize time on your PC with time on the US Military Time Server. 
  Accurate to the second</li>
</ul>
		<p align="center"><b>
		<img border="0" src="TabView/images/info.gif" width="16" height="16"> 
		<a href="template.php?TB=whenonearth_body.php">Read more</a>&nbsp;&nbsp;
		<img border="0" src="TabView/images/buy.gif" width="15" height="15"> 
		<a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-2">Purchase</a>&nbsp;&nbsp;
		<img border="0" src="TabView/images/download.gif" width="16" height="16"> 
		<a href="http://users.tpg.com.au/adsld842/WhenOnEarth110.exe">Download</a>&nbsp;&nbsp; </b>
		<img border="0" src="TabView/images/search.gif" width="16" height="16">
		<b><a href="template.php?TB=whenonearth_ss.php">Screenshots</a></b></p>
		