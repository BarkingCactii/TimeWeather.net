    <p class="small" align="center">WorldTime2003 3.0 Default skin<br>
	<b>Click to enlarge</b></p>
	<p class="small" align="center">
	<a href="http://users.tpg.com.au/adsld842/wt2kv3%20screen%201.gif">
	<img border="0" src="http://users.tpg.com.au/adsld842/wt2kv3%20screen%201.gif" width="117" height="62"></a></p>
	<p class="small" align="center">
	<a href="http://users.tpg.com.au/adsld842/wt2kv3%20screen%202.gif">
	<img border="0" src="http://users.tpg.com.au/adsld842/wt2kv3%20screen%202.gif" width="118" height="65"></a></p>
	<p class="small" align="center">Screen shots of WorldTime2000 
2.00 with different themes prior to application skinning. Click to enlarge<a href="file:///C:/Documents%20and%20Settings/Jeff%20H/My%20Documents/My%20Webs/WebCentral/images/sample3.gif">
<br>
</a><br>
<a href="http://users.tpg.com.au/adsld842/images/sample1.gif">
<img alt="A light, cloudy theme" src="http://users.tpg.com.au/adsld842/images/sample1_small.gif" border="2" width="100" height="48"></a></p>
<p class="small" align="center">
<a href="http://users.tpg.com.au/adsld842/images/sample2.gif">
<img alt="A dark theme using a picture as the background" src="http://users.tpg.com.au/adsld842/images/sample2_small.gif" border="2" width="100" height="48"></a><a href="file:///C:/Documents%20and%20Settings/Jeff%20H/My%20Documents/My%20Webs/WebCentral/images/sample1.gif"><br>
</a><br>
<a href="http://users.tpg.com.au/adsld842/images/sample3.gif">
<img alt="Default theme" src="http://users.tpg.com.au/adsld842/images/sample3_small.gif" border="2" width="100" height="60"></a><br>
<br>
<a href="http://users.tpg.com.au/adsld842/images/tray.gif">
<img alt="tray.gif (2458 bytes)" src="http://users.tpg.com.au/adsld842/images/tray_small.gif" border="2" width="100" height="54"></a></p>
	<p class="small" align="center">WorldTime2000 in the system tray </p>


