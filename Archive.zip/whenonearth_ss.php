    <p class="small" align="center">Screenshots of WhenOnEarth</p>
	<p class="small" align="center">
	<a href="http://users.tpg.com.au/adsld842/images/WOE_ss1.gif"><img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_ss1.gif" width="100" height="65" alt="Click to enlarge"></a></p>
	<p class="small" align="center">default with locations plotted on map<a href="http://users.tpg.com.au/adsld842/images/WOE_ss1.gif"><br>
    </a><a href="http://www.home.aone.net.au/pcm/WhenOnEarth.exe"><b><br>
    </b></a><a href="http://users.tpg.com.au/adsld842/images/WOE_ss2.gif"><img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_ss2.gif" width="100" height="64"></a></p>
	<p class="small" align="center">List view</p>
	<p class="small" align="center"><a href="http://users.tpg.com.au/adsld842/images/WOE_ss3.gif"><img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_ss3.gif" width="100" height="64"></a></p>
	<p class="small" align="center">A bit of customizing changes the look...
    </p>
    <p class="small" align="center"><a href="http://users.tpg.com.au/adsld842/images/WOE_window.gif"><font color="#000080"><img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_window.gif" width="90" height="43"></font></a></p>
	<p class="small" align="center">Don't want to see the map ? Hide in the 
	system tray and make a floating window of only the locations of interest</p>
	<p class="small" align="center">&nbsp;</p>