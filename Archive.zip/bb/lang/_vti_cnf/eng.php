vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 Aug 2004 00:20:32 -0000
vti_extenderversion:SR|6.0.2.5516
vti_cacheddtm:TX|03 Aug 2004 00:20:32 -0000
vti_filesize:IR|12869
vti_backlinkinfo:VX|
