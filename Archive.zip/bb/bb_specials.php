<?php
$clForums=array();
$roForums=array();
$poForums=array();
$userRanks=array();
$regUsrForums=array();
$mods=array();
?>