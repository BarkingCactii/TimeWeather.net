INSERT INTO {SQL_TABLE_PREFIX}cat (name,description,cat_opt,view_order) VALUES ('Test Category', ' - Just a test category', 1|2, 1);
