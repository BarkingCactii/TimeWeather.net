INSERT INTO {SQL_TABLE_PREFIX}level (name,post_count) VALUES ('Senior Member',100);
INSERT INTO {SQL_TABLE_PREFIX}level (name,post_count) VALUES ('Member',30);
INSERT INTO {SQL_TABLE_PREFIX}level (name,post_count) VALUES ('Junior Member',0);
