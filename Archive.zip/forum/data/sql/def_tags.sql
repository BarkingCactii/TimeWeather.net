INSERT INTO {SQL_TABLE_PREFIX}custom_tags (name, user_id) VALUES ('Administrator', 2);
