vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|01 May 2005 10:12:23 -0000
vti_extenderversion:SR|6.0.2.5516
vti_cacheddtm:TX|01 May 2005 10:12:23 -0000
vti_filesize:IR|3029
vti_backlinkinfo:VX|
