<?php
/**
* copyright            : (C) 2001-2004 Advanced Internet Designs Inc.
* email                : forum@prohost.org
* $Id: avatarsel.php.t,v 1.14 2005/03/18 01:58:51 hackie Exp $
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License as published by the
* Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
**/

	define('plain_form', 1);

if (_uid === '_uid') {
		exit('sorry, you can not access this page');
	}function alt_var($key)
{
	if (!isset($GLOBALS['_ALTERNATOR_'][$key])) {
		$args = func_get_args(); unset($args[0]);
		$GLOBALS['_ALTERNATOR_'][$key] = array('p' => 2, 't' => func_num_args(), 'v' => $args);
		return $args[1];
	}
	$k =& $GLOBALS['_ALTERNATOR_'][$key];
	if ($k['p'] == $k['t']) {
		$k['p'] = 1;
	}
	return $k['v'][$k['p']++];
}function tmpl_draw_select_opt($values, $names, $selected)
{
	$vls = explode("\n", $values);
	$nms = explode("\n", $names);

	if (count($vls) != count($nms)) {
		exit("FATAL ERROR: inconsistent number of values inside a select<br>\n");
	}

	$options = '';
	foreach ($vls as $k => $v) {
		$options .= '<option value="'.$v.'"'.($v == $selected ? ' selected' : '' )  .'>'.$nms[$k].'</option>';
	}

	return $options;
}


	$TITLE_EXTRA = ': Avatar Selection Form';

	$galleries = array();
	$c = uq("SELECT DISTINCT(gallery) FROM fud26_avatar");
	while ($r = db_rowarr($c)) {
		$galleries[$r[0]] = htmlspecialchars($r[0]);
	}
	unset($c, $r);

	if (count($galleries) > 1) {
		$gal = isset($_POST['gal'], $galleries[$_POST['gal']]) ? $_POST['gal'] : 'default';
		$select = tmpl_draw_select_opt(implode("\n", $galleries), implode("\n", array_keys($galleries)), $gal);
		$select = '<form name="avsel" method="post" action="index.php?t=avatarsel">'._hs.'
<select name="gal" onChange="javascript: document.avsel.submit();">'.$select.'</select> <input type="submit" name="sbm" value="View">
</form><hr />';
	} else {
		$gal = 'default';
		$select = '';
	}

	/* here we draw the avatar control */
	$icons_per_row = 5;
	$c = uq("SELECT id, descr, img FROM fud26_avatar WHERE gallery='".$gal."' ORDER BY id");
	$avatars_data = '';
	$col = 0;
	while ($r = db_rowarr($c)) {
		if (!($col++ % $icons_per_row)) {
			$avatars_data .= '</tr><tr>';
		}
		$avatars_data .= '<td class="'.alt_var('avatarsel_cl','Av1','Av2').'">
<a href="javascript: window.opener.document.fud_register.reg_avatar.value=\''.$r[0].'\'; window.opener.document.reg_avatar_img.src=\'images/avatars/'.$r[2].'\'; window.close();"><img src="images/avatars/'.$r[2].'" alt="" /><br /><span class="SmallText">'.$r[1].'</span></a></td>';
	}

	if (!$avatars_data) {
		$avatars_data = '<td class="NoAvatar">No Avatars available</td>';
	}


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-15">
<title><?php echo $GLOBALS['FORUM_TITLE'].$TITLE_EXTRA; ?></title>
<BASE HREF="http://timeweather.net/forum/">
<script language="JavaScript" src="lib.js" type="text/javascript"></script>
<link rel="StyleSheet" href="theme/default/forum.css" type="text/css">
</head>
<body>
<table class="wa" border="0" cellspacing="3" cellpadding="5"><tr><td class="ForumBackground">
<?php echo $select; ?>
<table border=0 cellspacing=1 cellpadding=2><tr>
<?php echo $avatars_data; ?>
</tr></table>
</td></tr></table></body></html>