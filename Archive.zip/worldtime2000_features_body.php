<u><b>Key Features of WorldTime2000</b></u> 
<ul>
  <li>WorldTime2000 is self extracting setup program, not a ZIP file. </li>
  <li>Just click & install

Windows Install feature 

</li>
  <li>Alarms can be set for displayed locations
 
</li>
  <li>Over 400 built-in locations including DST details This includes cities and time zones

  </li>
  <li>Text will automatically resize itself to the width of the window 

</li>
  <li>Text and background colors user definable 

</li>
  <li>An animated spinning globe. It doesn't do anything, but it looks good! 

  </li>
  <li>Right mouse button ( context ) menus implemented 

</li>
  <li>HTML help. That means help looks and acts just like a web page 

</li>
  <li>Locations can be viewed, modified and deleted 

</li>
  <li>Display preferences are saved ( window details, colors, toolbars etc )
  </li>
  <li>Time is adjusted according to the Daylight Savings rules for that location
  </li>
  <li>30 min and 1 hour increments from GMT </li>
  <li>Select between 12 or 24 hour time </li>
  <li>Home location's time zone set automatically. </li>
  <li>Home can be changed to any name of your liking </li>
  <li>You get to see your name on the display when you register</li>
</ul>
