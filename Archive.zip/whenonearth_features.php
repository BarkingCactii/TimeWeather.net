<?php

define ( PRODUCT, -1 );
define ( COUNT, -1 );

define ("BODY", "whenonearth_features_body.php", true );
//define ("LEFT_SIDEBAR", "worldtime2003_leftside.php", true );
//define ("RIGHT_SIDEBAR", "worldtime2003_rightside.php", true );
include ('template.php')

?>