<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_s-xclick">
<p>
<b><h1 align="center">Pay with PayPal</h1></b>
<p align="center"></p>
<p align="center">You can now pay using 
PayPal. It's quick and easy. The purchase price is $9 for WorldTime2000 &amp; 
WhenOnEarth, or $12.95 for WorldTime2003. Just click on the PayPal logo below</p>
<p align="center">.<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but5.gif" border="0" name="I1" alt="Make payments with PayPal - it's fast, free and secure!" width="150" height="52">
<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----
MIIG7QYJKoZIhvcNAQcEoIIG3jCCBtoCAQExggEwMIIBLAIBADCBlDCBjjELMAkG
A1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQw
EgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UE
AxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJ
KoZIhvcNAQEBBQAEgYB7zbARuDgTz90E+yLAnVlFgPhN6ICFKRTyOquaR3AA4/Ay
KXCai2nzpTfnJ7tWIJxv6O3kMdFfkHJENKBjOAWL10kK/6SxFtahpufCQaHs/hOt
AIhShbdbd3pO2HmiQhAFK9FfvN3JFGy+FC2MNUrhZorsV9vNRWpx5FO3duBzoTEL
MAkGBSsOAwIaBQAwawYJKoZIhvcNAQcBMBQGCCqGSIb3DQMHBAjPfYBiikdMlIBI
wj6Eu661xjv+VCfumzO1HP8Jgi2TOLc9vM5VsaxTuXTm9TVgNm4+TLiF7awgVjU9
4lXdaXS0JYwCMgZS0MP2gRO6X9ItQ/N0oIIDhzCCA4MwggLsoAMCAQICAQAwDQYJ
KoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UE
BxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsU
CmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1y
ZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4x
CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmll
dzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAP
BgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGf
MA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6Ci
eLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4S
Zeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u
9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ
1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCB
jjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBW
aWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czER
MA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22C
AQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6uj
ionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk
1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWz
FGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJV
UzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoT
C1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZl
X2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUA
oF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMDQw
NTEwMDMxODM1WjAjBgkqhkiG9w0BCQQxFgQUwsPA/6m1yMousJL0C4MZEf1SORYw
DQYJKoZIhvcNAQEBBQAEgYAQgMBo5AWt7/8z3LDlV1cfAZ+i2h9/QaoOzgsvWzUI
gbosUt9zLHuT5TNolAafvUEHGVhueegBTQLb9pl8w4Hy6qJjICZDN4E6c5V3Bs+i
eBfLF6HnYAcJ38rMmb6uyp3lL2pZMBsz+XJ3v0qxUtzBZBe8RVJMRwdDvFuFkEPD
dw==
-----END PKCS7-----
">
</p>
</form>
    
      
    <p align="center">
    <img border="0" src="http://users.tpg.com.au/adsld842/images/dolphin.gif" alt="Hello! My name is Cindy!" width="101" height="58"><p align="center">
    <u>WorldTime2003 Awards</u><p align="center">
    &nbsp;<div align="center">
              <a href="http://www.FileHeaven.com">
              <img border="0" src="http://users.tpg.com.au/adsld842/images/cup_5.gif" width="91" height="50"></a></div>
            <p align="center">Awarded by
            <a href="http://www.fileheaven.com/WorldTime2003/download/8735.htm">
            FileHeaven</a> </p>
            <p align="center">
            <img title="Software - Rating : 5" src="http://users.tpg.com.au/adsld842/images/downloadrate5.gif" width="63" height="13"><br>
            Awarded by
            <a href="http://www.brothersoft.com/software.asp?subcategoryid=48&softid=22437">
            BrotherSoft</a></p>
            <p align="center">
            <img src="http://users.tpg.com.au/adsld842/images/5star.gif" width="100" height="62"><br>
            Awarded by <a href="http://www.filetransit.com/view.php?id=17854">
            FileTransit</a></p>
            <p align="center">
            <img src="http://users.tpg.com.au/adsld842/images/shareup_logo_5.gif" width="98" height="31"><br>
            Awarded by
            <a href="http://www.shareup.com/WorldTime2003-download-9328.html">
            Shareup</a></p>
            <p align="center">
            <img src="http://users.tpg.com.au/adsld842/images/5GoldDisk-Award-small.gif" border="0" width="80" height="80"><br>
            Awarded by
            <a href="http://www.worldtime2003.net-software-download.com/">
            SharewareSoft</a></p>
            <p align="center">
            <a href="http://www.topshareware.com">
            <img src="http://users.tpg.com.au/adsld842/images/cup_5_2.gif" alt="5 stars rating at TopShareware.com" width="100" height="61" border="0"></a><br>
            Awarded by
            <a href="http://www.topshareware.com/WorldTime2003-download-8735.htm">
            TopShareware</a></p>
            <p align="center">&nbsp;</p>