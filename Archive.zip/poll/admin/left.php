<table border='2' width='100%' bordercolor='red'>
<tr>
<td bgcolor='red'><font color='white'><b>Admin Options</b></font></td></tr>
<tr><td bgcolor='white'>
<A href='addchoice.php'>Add poll choice</a><br><br>
<A href='deletechoice.php'>Delete Poll Choice</a><br><br>
<A href='editchoice.php'>Edit Poll Choice</a><br><br>
<A href='deletepoll.php'>Delete Poll</a><br><br>
<A href='createpoll.php'>Create Poll</a><br><br>
<A href='edit.php'>Edit Poll</a><br><br>
</td></tr></table>
