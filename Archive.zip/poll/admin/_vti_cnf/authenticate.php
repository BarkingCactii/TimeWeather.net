vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Sep 2003 05:26:56 -0000
vti_author:SR|JEFF\\Jeff H
vti_modifiedby:SR|JEFF\\Jeff H
vti_nexttolasttimemodified:TR|27 Sep 2003 05:26:56 -0000
vti_timecreated:TR|13 May 2004 01:25:59 -0000
vti_extenderversion:SR|5.0.2.2623
vti_syncwith_localhost\\c\:\\documents and settings\\jeff h\\my documents\\my webs\\home/c\:/documents and settings/jeff h/my documents/my webs/home:TR|27 Sep 2003 05:26:56 -0000
vti_lineageid:SR|{8BCAB991-83A3-4DD0-981C-59A9905F6863}
vti_cacheddtm:TX|13 May 2004 01:25:59 -0000
vti_filesize:IR|657
vti_backlinkinfo:VX|
