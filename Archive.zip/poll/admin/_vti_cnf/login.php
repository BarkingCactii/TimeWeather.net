vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Feb 2003 14:24:00 -0000
vti_author:SR|JEFF\\Jeff H
vti_modifiedby:SR|JEFF\\Jeff H
vti_nexttolasttimemodified:TR|21 Feb 2003 14:24:00 -0000
vti_timecreated:TR|13 May 2004 01:25:59 -0000
vti_extenderversion:SR|5.0.2.2623
vti_syncwith_localhost\\c\:\\documents and settings\\jeff h\\my documents\\my webs\\home/c\:/documents and settings/jeff h/my documents/my webs/home:TR|21 Feb 2003 14:24:00 -0000
vti_lineageid:SR|{E84B076E-90C6-45D1-8878-8CE831CD8FC1}
vti_cacheddtm:TX|13 May 2004 01:25:59 -0000
vti_filesize:IR|278
vti_backlinkinfo:VX|
