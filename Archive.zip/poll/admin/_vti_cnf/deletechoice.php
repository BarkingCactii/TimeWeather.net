vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Sep 2003 00:16:42 -0000
vti_author:SR|JEFF\\Jeff H
vti_modifiedby:SR|JEFF\\Jeff H
vti_nexttolasttimemodified:TR|18 Sep 2003 00:16:42 -0000
vti_timecreated:TR|13 May 2004 01:25:59 -0000
vti_extenderversion:SR|5.0.2.2623
vti_syncwith_localhost\\c\:\\documents and settings\\jeff h\\my documents\\my webs\\home/c\:/documents and settings/jeff h/my documents/my webs/home:TR|18 Sep 2003 00:16:42 -0000
vti_lineageid:SR|{E6345D74-3991-48AC-B9B4-E9E08BBDB376}
vti_cacheddtm:TX|13 May 2004 01:25:59 -0000
vti_filesize:IR|2913
vti_backlinkinfo:VX|
