vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Aug 2003 03:36:40 -0000
vti_author:SR|JEFF\\Jeff H
vti_modifiedby:SR|JEFF\\Jeff H
vti_nexttolasttimemodified:TR|21 Aug 2003 03:36:40 -0000
vti_timecreated:TR|13 May 2004 01:25:59 -0000
vti_extenderversion:SR|5.0.2.2623
vti_syncwith_localhost\\c\:\\documents and settings\\jeff h\\my documents\\my webs\\home/c\:/documents and settings/jeff h/my documents/my webs/home:TR|21 Aug 2003 03:36:40 -0000
vti_lineageid:SR|{CFD5EDC4-374B-4657-8D1F-AB6AE4DF5230}
vti_cacheddtm:TX|13 May 2004 01:25:59 -0000
vti_filesize:IR|489
vti_backlinkinfo:VX|
