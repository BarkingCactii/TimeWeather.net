                
<h4>Buy our Software</h4>
<p>All of our software comes in the form of shareware, which means you can try 
the software with no restructions for a period of 28 days, then if you wish to 
continue using the product, you are encouraged to register. To purchase our 
software select the product below and follow the directions.</p>
<p><img border="0" src="TabView/images/buy.gif" width="15" height="15">&nbsp;
<a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-1">Buy 
WorldTime2000</a></p>
<p><img border="0" src="TabView/images/buy.gif" width="15" height="15">
<a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-2">Buy 
WhenOnEarth</a></p>
<p><img border="0" src="TabView/images/buy.gif" width="15" height="15">
<a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-3">Buy 
WorldTime2003</a></p>
<p>&nbsp;</p>


<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----
MIIG7QYJKoZIhvcNAQcEoIIG3jCCBtoCAQExggEwMIIBLAIBADCBlDCBjjELMAkG
A1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQw
EgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UE
AxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJ
KoZIhvcNAQEBBQAEgYB7zbARuDgTz90E+yLAnVlFgPhN6ICFKRTyOquaR3AA4/Ay
KXCai2nzpTfnJ7tWIJxv6O3kMdFfkHJENKBjOAWL10kK/6SxFtahpufCQaHs/hOt
AIhShbdbd3pO2HmiQhAFK9FfvN3JFGy+FC2MNUrhZorsV9vNRWpx5FO3duBzoTEL
MAkGBSsOAwIaBQAwawYJKoZIhvcNAQcBMBQGCCqGSIb3DQMHBAjPfYBiikdMlIBI
wj6Eu661xjv+VCfumzO1HP8Jgi2TOLc9vM5VsaxTuXTm9TVgNm4+TLiF7awgVjU9
4lXdaXS0JYwCMgZS0MP2gRO6X9ItQ/N0oIIDhzCCA4MwggLsoAMCAQICAQAwDQYJ
KoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UE
BxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsU
CmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1y
ZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4x
CzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmll
dzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAP
BgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGf
MA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6Ci
eLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4S
Zeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u
9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ
1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCB
jjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBW
aWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czER
MA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22C
AQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6uj
ionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk
1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWz
FGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJV
UzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoT
C1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZl
X2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUA
oF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMDQw
NTEwMDMxODM1WjAjBgkqhkiG9w0BCQQxFgQUwsPA/6m1yMousJL0C4MZEf1SORYw
DQYJKoZIhvcNAQEBBQAEgYAQgMBo5AWt7/8z3LDlV1cfAZ+i2h9/QaoOzgsvWzUI
gbosUt9zLHuT5TNolAafvUEHGVhueegBTQLb9pl8w4Hy6qJjICZDN4E6c5V3Bs+i
eBfLF6HnYAcJ38rMmb6uyp3lL2pZMBsz+XJ3v0qxUtzBZBe8RVJMRwdDvFuFkEPD
dw==
-----END PKCS7-----
">
<input type="hidden" name="cmd" value="_s-xclick">
<b>
<h4 align="left">Pay with PayPal</h4></b>
<p align="center"></p>
<p align="left">You can also buy our software using PayPal. It's quick and easy. The purchase price is $9 for WorldTime2000 &amp; 
WhenOnEarth, or $12.95 for WorldTime2003. Just click on the PayPal logo below</p>
<p align="left">Note: Be sure to mention in your PayPal statement which product 
you are ordering..<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but5.gif" border="0" name="I1" alt="Make payments with PayPal - it's fast, free and secure!" width="150" height="52" align="left"></p>
</form>


