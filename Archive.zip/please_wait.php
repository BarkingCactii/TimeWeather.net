<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Please wait</title>
</head>

<body>

<table border="1" width="100%" id="table1" bgcolor="#000080">
	<tr>
		<td>
		<h3 align="center"><font color="#FFFFFF">Please wait. You will be 
		automatically redirected in 3 seconds. </font></h3>
		<h3 align="center"><font color="#FFFFFF">If you are not automatically 
		redirected, please click on the link below</font></h3>
		</td>
	</tr>
	<tr>
		<td bgcolor="#C0C0C0">
		<p align="center"><font color="#FFFFFF">
		<a href="http://timeweather.net">timeweather.net</a></font></td>
	</tr>
</table>

</body>

</html>

<?php

header("Location: http://timeweather.net");
exit();

?>