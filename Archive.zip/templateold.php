<html>

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>World Time Shareware Applications - Jeffs-Software.com</title>
<meta NAME="Classification" CONTENT="world time software, time zone software,times,zones,time zones,time zone,world time zones,international time zones,display time zones,time zone map,different time zones,world map,travel time zones,free updates,shareware,software,freeware,daylight savings,alarm clock,desktop,32-bit,Windows 95,Windows 98,Windows NT,Windows 2000,Windows XP">
<meta NAME="description" CONTENT="Shareware WorldTime2000. WhenOnEarth, WorldTime2003 View different world time zones from around the world on a map">
<meta NAME="keywords" CONTENT="world time software,times,zones,time zones,time zone,world time zones,international time zones,display time zones,time zone map,different time zones,travel time zones,world map,free updates,shareware,software,freeware,daylight savings,alarm clock,desktop">
<link rel="stylesheet" type="text/css" href="stylesheet.CSS">
</head>


<body bgcolor="#ffffff" topmargin="0">
 

<?php
	include ('banner.php' );
	include ('menu.php' );
?>

<!--<font size="1" face="MS Sans Serif"> -->
<!-- Gradient -->
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" bgcolor="#99CCFF" height="29" background="http://users.tpg.com.au/adsld842/images/banner_gradient.GIF">
  <tr>
    <td width="100%" height="29">
  &nbsp;</tr>
</table>

<!-- Sidebars -->
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="20">
  <tr>
    <td width="180" background="http://users.tpg.com.au/adsld842/images/sidebar-left.gif" height="20">&nbsp;</td>
    <td bgcolor="#FFFFFF" height="20">&nbsp;</td>
    <td width="200" background="http://users.tpg.com.au/adsld842/images/sidebar_right.gif" height="20">&nbsp;</td>
  </tr>
</table>

<!-- main display -->
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="593" bgcolor="#FFFFFF">
  <tr>
    <td width="155" bgcolor="#C0C0FF" valign="top">
    
    <!-- left menu -->
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" bgcolor="#C0C0FF">
    <tr>
        <td align="top" width="100%" bgcolor="#00FFFF" valign="top">
        <p align="center"><font color="#000000" size="4"><b>
        Products<br>
&nbsp;</b></font></td>
      </tr>

      <tr>
        <td align="top" width="100%" bgcolor="#000080" valign="top">
        <p align="justify"><font color="#FFFFFF"><b>
        <u><font size="3">WorldTime2003</font></u><br>
		Displays world times using custom skins</b></font></td>
      </tr>
      <tr>
        <td width="100%" height="17" bordercolorlight="#00FF00" bordercolordark="#008000">
        <a href="worldtime2003.php">Main page</a></td>
      </tr>
      <tr>
        <td width="100%" height="17"><a href="worldtime2003_features.php">
        Features</a></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="http://www.home.aone.net.au/pcm/WorldTime2003.exe">
        Download</a></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-3">
        Buy it</a></td>
      </tr>
      <tr>
        <td width="100%" bgcolor="#000080" height="17">
        <p align="justify"><font color="#FFFFFF"><b>
        <u><font size="3">WhenOnEarth</font></u><br>
		Displays world times on a world map</b></font></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="whenonearth.php">Main page</a></td>
      </tr>
      <tr>
        <td width="100%" height="17"><a href="whenonearth_features.php">
        Features</a></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="http://www.home.aone.net.au/pcm/WhenOnEarth110.exe">
        Download</a></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-2">
        Buy it</a></td>
      </tr>
      <tr>
        <td width="100%" bgcolor="#000080" height="17">
        <p align="justify"><font color="#FFFFFF"><b>
        <u><font size="3">WorldTime2000</font></u><br>
		Displays world times in list format. Also supports skins</b></td></font>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="worldtime2000.php">Main page</a></td>
      </tr>
      <tr>
        <td width="100%" height="17"><a href="worldtime2000_features.php">
        Features</a></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="http://users.tpg.com.au/adsld842/WorldTime2000-3.0.exe">Download</a></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="https://www.regnow.com/softsell/nph-softsell.cgi?item=2185-1">
        Buy it</a></td>
      </tr>
      <tr>
        <td width="100%" height="17"></td>
      </tr>
      <tr>
        <td width="100%" bgcolor="#00FFFF" height="17">
        <p align="center"><b>
        <font color="#000000" size="4">Contact Us<br>
&nbsp;</font></b></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="mailto:comments@jeffs-software.com?subject=I have a comment">
        Comments</a></td>
      </tr>
      <tr>
        <td width="100%" height="17">
        <a href="mailto:support@jeffs-software.com?subject=I have a support question">
        Support</a></td>
      </tr>
      <tr>
        <td width="100%" height="17"></td>
      </tr>
      <tr>
        <td width="100%" height="17"></td>
      </tr>
      <tr>
        <td width="100%" height="17"></td>
      </tr>
      <tr>
        <td width="100%" height="17"></td>
      </tr>
      <tr>
        <td width="100%" height="17"></td>
      </tr>
      <tr>
        <td width="100%"></td>
      </tr>
    </table>

<?php

include ( LEFT_SIDEBAR );  

function DisplayHistory ()
{

	$year = date('Y');
	$month = date('m');
	$day = date('d');
	
//	$query = 'SELECT * FROM visitlog order by date desc limit 0, 10';
	$query = 'SELECT * FROM visitlog where date like "'.$year.'-'.$month.'-'.$day.'%" order by date';
//	echo $query;
//	return true;

	
	$result = mysql_query( $query );
	
//	if ( !$result )
//		return false;
	
	$num_rows = mysql_num_rows ( $result );

	if ( $num_rows == 0 )
		return false;


echo 'Served '.$num_rows.'<br>';
$row = mysql_fetch_object ( $result );
echo 'Last '.$row->ip.'<br>';
return true;
/*
	for ( $i = 0; $i < $num_rows; $i++ )
	{
		$row = mysql_fetch_object ( $result );

		$ip = $row->ip;
		#dn = $row->domainname;
		echo $ip;
		echo $dn;
//		echo strtotime($date);
//		echo date ('d F, Y', strtotime($date));
//		$date = FORMAT_DATE ( $date, '%D %M %Y');
//		$date = date ('d F, Y', strtotime($date));
//		$description = $row->description;

//		echo '<h1>'.$date;
//		if ( $whichProduct == 0 )
//		{
//			$productName = GetProductName ( $row->productID );
//			echo ' <font size="1">( '.$productName.' )</font>';
//		}
//		echo '</h1>';	
//
//		echo '<p>'.$description.'</p>';
	}

	return true;
	*/
}

echo date ('jS F Y' ).'<br>';  

$url = $HTTP_SERVER_VARS['URL'];
@ $db = mysql_pconnect('localhost', 'webuser', 'goose1604');

if (!$db)
{
	echo 'Error: Could not connect to database.';
	exit;
}

mysql_select_db ( 'web' );

	
	DisplayHistory();
?>
    </td>

    <td rowspan="2" valign="top" height="100%" align="left" bgcolor="#FFFFFF">
    &nbsp;
    <!-- contents go here -->
    

    <?php
    	include ( BODY );
    	include ( 'news.php' );
		include ( 'counter.php' );
    ?>

    </td>

    <td width="175" bgcolor="#C0C0FF" rowspan="2" height="593" valign="top">
    
    <!-- right side goes here -->

    <?php
		include ( RIGHT_SIDEBAR );    
    ?>

    </td>

  </tr>

  <tr>
    <td width="155" bgcolor="#C0C0FF"></td>
  </tr>

  </table>
<!--</font>-->
</body>

</html>