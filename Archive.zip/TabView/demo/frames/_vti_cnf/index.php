vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Oct 2003 19:02:00 -0000
vti_extenderversion:SR|6.0.2.5516
vti_cacheddtm:TX|13 Oct 2003 19:02:00 -0000
vti_filesize:IR|637
vti_backlinkinfo:VX|
