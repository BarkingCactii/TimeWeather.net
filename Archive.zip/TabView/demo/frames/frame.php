<?php
/******************************
	
	Filename: frame.php
	Created: December 12, 2002 
	Author: Brad Touesnard
	Copyright: Copyright � 2002 Zenutech.com

	Last Modified: 
	Last Modified By: 

 ******************************/
?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title>TabView Frames Demo</title>

<link rel="stylesheet" href="../../stylesheet.php" type="text/css">

</head>

<body bgcolor="#FFFFFF" text="#000000" link="#FF0000" alink="#FF0000" vlink="#FFCCCC">

<table width="98%" cellpadding="0" cellspacing="0">
<tr>
	<td>
		<table width="100%" border="1" bordercolor="#CCCCFF" cellpadding="8" cellspacing="0">
		<tr>
			<td bgcolor="FAFAFA">
			<h2>Tab chosen: <?=$_GET['TB']?></h2>
			</td>
		</tr>
		</table>
	</td>
</tr>
</table>
<br>
