<?php
/******************************
	
	Filename: index.php
	Created: December 12, 2002 
	Author: Brad Touesnard
	Copyright: Copyright � 2002 Zenutech.com

	Last Modified: 
	Last Modified By: 

 ******************************/
?>
<!doctype html public "-//w3c//dtd html 4.0 transitional//en">
<html>
<head>
<title>TabView Frames Demo</title>
</head>

<frameset rows="30,*">
	<frame src="tabs.php" name="tabs_frame" frameborder="0" noresize="true" scrolling="no"></frame>
	<frame src="frame.php" name="main_frame" frameborder="0" noresize="true" scrolling="auto"></frame>
</frameset><noframes></noframes>

</html>