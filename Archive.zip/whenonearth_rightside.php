   <p align="center">View different locations on a map of the world or in
 their own compact window.&nbsp;</p>
                <p align="center">
                Requires Windows  98/ME/NT4/2000/XP<p align="center">
   <img border="0" src="http://users.tpg.com.au/adsld842/images/small_globe.gif" width="32" height="32"><p class="small" align="center"><u>
Screenshots -</u> <u>Click
    to enlarge</u>
    
    </p>
    <p class="small" align="center"><a href="http://users.tpg.com.au/adsld842/images/WOE_ss1.gif"><img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_ss1.gif" width="100" height="65" alt="Click to enlarge"><br>
    </a><a href="http://www.home.aone.net.au/pcm/WhenOnEarth.exe"><b><br>
    </b></a><a href="http://users.tpg.com.au/adsld842/images/WOE_ss2.gif"><img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_ss2.gif" width="100" height="64"><br>
    <br>
    </a><a href="http://users.tpg.com.au/adsld842/images/WOE_ss3.gif"><img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_ss3.gif" width="100" height="64"></a>
    </p>
    <p class="small" align="center"><a href="http://users.tpg.com.au/adsld842/images/WOE_window.gif"><font color="#000080"><img border="0" src="http://users.tpg.com.au/adsld842/images/WOE_window.gif" width="90" height="43"></font></a></p>