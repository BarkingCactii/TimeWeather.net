<?php

header("Location: http://timeweather.net/template.php?TB=worldtime2000_body.php");
exit();

?>