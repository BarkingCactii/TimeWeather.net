                
<h4>Downloads</h4>
<p>All of our software comes in the form of shareware, which means you can try 
the software with no restrictions for a period of 28 days, then if you wish to 
continue using the product, you are encouraged to register. Download any of the 
software by clicking the links below. </p>
<p>WorldTime2000</p>
<p>&nbsp;<img border="0" src="TabView/images/download.gif" width="16" height="16">
<a href="ftp://users.tpg.com.au/WorldTime2000-3.0.exe">Version 3.0</a></p>
<p>WhenOnEarth</p>
<p><img border="0" src="TabView/images/download.gif" width="16" height="16">
<a href="http://users.tpg.com.au/adsld842/WhenOnEarth110.exe">Version 1.10</a></p>
<p>WorldTime2003</p>
<p><img border="0" src="TabView/images/download.gif" width="16" height="16">
<a href="http://users.tpg.com.au/adsld842/WorldTime2003.exe">Version 1.0</a></p>
<p>&nbsp;</p>

