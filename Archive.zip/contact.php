                
                <p>You may email us via our form below. Emails 
				will be responded to as quickly as possible.</p>
				
				<?php
				include ('contact_form.php');
				?>