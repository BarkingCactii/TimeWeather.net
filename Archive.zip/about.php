<body style="background-attachment: fixed">

<p align="center" class="heading">TimeWeather.NET is located in Brisbane, QLD, Australia</p>
<p align="center" class="heading">
   <img border="0" src="images/ibrislge.gif" width="90" height="90" align="left">
</p>
<p>This web server is served from my own machine at home with a static DSL connection from 
		<a href="http://www.tpg.com.au">TPG</a>
		. In my frustration finding a local hosting company that supports PHP and SQL at a 
		reasonable cost, I decided to set one up myself to see how difficult it was. 
		Needless to say, setting up these applications was time consuming and fiddly, but 
		nothing too difficult. 
</p>
<p>This website exists for 2 reasons:</p>
<ul>
	<li>showcase the products I have written and hopefully make 
	a little income for my efforts</li>
	<li>to demonstrate to prospective employers that you don't 
	need 2 years experience to develop a web site</li>
</ul>
            <p>The site runs on Windows using IIS,
<a href="http://www.php.net/">PHP</a> and 
<a href="dev.mysql.org">MySQL</a> running on a Western Digital 
Raptor 10k rpm SATA hard drive with 2Gb Ram and a
<a href="http://www.draytek.com.au/">Draytek 2600+</a> router 
for those technically minded types. This machine runs 
everything; development applications, email, games ( and with a 
decent ping rate I hope! ). If it doesn't, make a nice donation 
through <a href="template.php?TB=buy.php">PayPal</a>, and I'll 
buy a dedicated machine.</p>
            <p>I am seeking casual employment in the IT field, 
            preferably in an application or website development role. I do 
have a job, but its night work. I wouldn't mind doing some day 
work as well.<p>Get my
<a href="http://users.tpg.com.au/adsld842/Resume%20-%20Jeff%20Hill.doc">resume</a> 
here<p><b><font face="Times New Roman">� TimeWeather.NET</font></b><p>